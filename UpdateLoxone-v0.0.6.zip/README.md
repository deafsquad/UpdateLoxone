# Loxone Auto Update Script (UpdateLoxone.ps1)

This PowerShell script automates the process of checking for, downloading, and installing updates for Loxone Config software and the Loxone App. It orchestrates the entire update workflow, including handling parameters, managing execution context (re-launching as the current user if initially run as SYSTEM), and registering a scheduled task for regular execution. The script can also trigger updates on configured Loxone Miniservers based on the installed Loxone Config version. It relies on a suite of `LoxoneUtils` modules for specific functionalities like logging, network operations, and installation tasks.

## Execution Flow Diagram

```mermaid
graph TD
    A[UpdateLoxone.ps1 Start] --> B(Parse Script Parameters);
    B --> C{Initial Run as SYSTEM?};
    C -- Yes --> D("Relaunch as Current User <br/> (LoxoneUtils.RunAsUser) <br/> with admin privileges <br/> if initially elevated");
    C -- No / Subsequent Run --> E(Import LoxoneUtils Modules);
    D --> E;
    E --> F("Initialize Workflow Context <br/> Paths, Logging, Versions <br/> (LoxoneUtils.Utility, <br/> LoxoneUtils.Logging)");
    F --> G{'-RegisterTask' Parameter?};
    G -- Yes --> H("Register/Update Sched. Task <br/> Runs as SYSTEM (highest priv.) <br/> (LoxoneUtils.System)");
    H --> ZTask["Exit (Task Registered)"];
    G -- No --> I("Fetch Update Prerequisites <br/> Check Loxone XML (local vs. remote) <br/> Uses -Channel and <br/> -UpdateLoxoneAppChannel <br/> (LoxoneUtils.UpdateCheck)");
    I --> J("Initialize Update Pipeline Data <br/> Targets: Config, App, Miniservers");
    J --> K_ExecutePipeline["Execute Update Pipeline <br/> (LoxoneUtils.WorkflowSteps)"];

    K_ExecutePipeline --> S1;

    subgraph pipeline_steps [Update Pipeline Steps]
        S1("S1: Download Loxone Config <br/> Get .zip; Verify CRC, <br/> filesize, cert (uses -EnableCRC, <br/> -SkipCertificateCheck) <br/> (LoxoneUtils.Network)") --> S2("S2: Extract Loxone Config <br/> Unzip archive <br/> (LoxoneUtils.Installation)");
        S2 --> S3("S3: Install Loxone Config <br/> Run with -InstallMode <br/> (LoxoneUtils.Installation)");
        S3 --> S4("S4: Download Loxone App <br/> Get .exe/.msi (if -UpdateLoxoneApp) <br/> Verify CRC, filesize, cert <br/> (uses -EnableCRC, -SkipCertCheck) <br/> (LoxoneUtils.Network)");
        S4 --> S5("S5: Install Loxone App <br/> Run with -InstallMode <br/> (LoxoneUtils.Installation)");
        S5 --> S6("S6: Check Miniserver Versions <br/> Compare installed Config ver. <br/> with MS firmware <br/> (LoxoneUtils.Miniserver)");
        S6 --> S7("S7: Update Miniservers <br/> Trigger if new Config ver. <br/> compatible and newer <br/> (LoxoneUtils.Miniserver)");
    end

    S7 --> L_Ops("Post-Pipeline Operations <br/> Error Handling, Logging, <br/> Notifications (LoxoneUtils.ErrorHandling, <br/> .Logging, .Toast)");
    L_Ops --> ZEnd["Exit (Workflow Complete)"];
```
## Features

*   **Orchestration (`UpdateLoxone.ps1`):**
    *   Manages the overall update process.
    *   Parses command-line parameters.
    *   Handles execution context, including re-launching as the current user if started as SYSTEM for the initial run.
    *   Supports task registration for automated execution.
*   **Modular Design (`LoxoneUtils`):** Utilizes a collection of specialized modules for various tasks:
    *   **`LoxoneUtils.WorkflowSteps`:** Defines and executes the individual steps of the update pipeline (Download Config, Install App, Update Miniservers, etc.).
    *   **`LoxoneUtils.UpdateCheck`:** Fetches the latest update information (versions for Config/App) from Loxone's official XML feed.
    *   **`LoxoneUtils.Network`:** Handles file downloads with progress indicators and verification.
    *   **`LoxoneUtils.Installation`:** Manages installer execution (silent/verysilent), version retrieval of installed software, finding installation paths, and ZIP file extraction.
    *   **`LoxoneUtils.Miniserver`:** Checks Miniserver versions and triggers updates on them.
    *   **`LoxoneUtils.Logging`:** Provides robust logging capabilities with automatic log rotation.
    *   **`LoxoneUtils.ErrorHandling`:** Implements detailed error logging to aid in troubleshooting.
    *   **`LoxoneUtils.Toast`:** Delivers desktop toast notifications for status updates and errors using the `BurntToast` module.
    *   **`LoxoneUtils.Utility`:** Contains general helper functions for path manipulation, software signature checks, string and version formatting, CRC checksums, and registry interactions.
    *   **`LoxoneUtils.System`:** Manages system processes and Windows Scheduled Tasks.
    *   **`LoxoneUtils.RunAsUser`:** Facilitates running processes as the currently interactive user, primarily used for the initial re-launch from SYSTEM context.
*   **Automatic Update Checks:** Regularly checks `update.loxone.com` for new versions based on the selected channel.
*   **Silent Installation:** Installs Loxone Config and App updates silently.
*   **Miniserver Updates:** Can trigger updates on Loxone Miniservers listed in `UpdateLoxoneMSList.txt`.
*   **Channel Selection:** Allows choosing between Release, Beta, or Test update channels for Loxone Config and the Loxone App.
*   **CRC Checksum Verification:** Optionally verifies the CRC32 checksum of downloaded installers.
*   **Process Handling:** Optionally closes running Loxone Config instances before updating or skips updates if Loxone Config is running.
*   **Scheduled Task Integration:** Can create/update a Windows Scheduled Task for periodic execution.
*   **Debug Mode:** Offers verbose logging for troubleshooting.

## Prerequisites

*   **PowerShell:** Version 5.1 or higher.
*   **`BurntToast` Module:** Required for desktop notifications. The script may attempt to install it if missing and run interactively or by the scheduled task.
*   **Windows OS:** Designed for Windows environments.
*   **Administrator Privileges:** Required for software installation and scheduled task management.
*   **Internet Access:** Necessary for downloading updates and the `BurntToast` module.
*   **`LoxoneUtils` Modules:** The `LoxoneUtils` directory containing all required `.psm1` module files must be present in the same directory as `UpdateLoxone.ps1`.

## Script Files

*   **`UpdateLoxone.ps1`:** The main orchestration script.
*   **`LoxoneUtils/` (Directory):** Contains the suite of PowerShell modules (`.psm1` files) that provide the core functionalities:
    *   `LoxoneUtils.ErrorHandling.psm1`
    *   `LoxoneUtils.Installation.psm1`
    *   `LoxoneUtils.Logging.psm1`
    *   `LoxoneUtils.Miniserver.psm1`
    *   `LoxoneUtils.Network.psm1`
    *   `LoxoneUtils.psd1` (Module manifest)
    *   `LoxoneUtils.psm1` (Main module file that likely loads others or acts as a wrapper)
    *   `LoxoneUtils.RunAsUser.psm1`
    *   `LoxoneUtils.System.psm1`
    *   `LoxoneUtils.Toast.psm1`
    *   `LoxoneUtils.UpdateCheck.psm1`
    *   `LoxoneUtils.Utility.psm1`
    *   `LoxoneUtils.WorkflowSteps.psm1`
*   **`Run-UpdateLoxoneTests.ps1`:** (If still present and used) A script for testing functions within the `LoxoneUtils` modules.

## Configuration Files

*(Place these files in the directory specified by `-ScriptSaveFolder`, which defaults to the script's own directory)*

*   **`UpdateLoxoneMSList.txt`:** (Optional) A text file containing connection details for Loxone Miniservers to be updated, one entry per line.
    *   Format: `http://username:password@ip-address-or-hostname` or `https://username:password@ip-address-or-hostname`.
    *   **Security Warning:** Passwords are stored in plain text. Ensure appropriate file permissions.
    *   If missing, Miniserver updates will be skipped.
*   **`UpdateLoxoneMSList.txt.example`:** An example file showing the format for `UpdateLoxoneMSList.txt`.
*   **Loxone Update XML:** The script fetches update information from `https://update.loxone.com/updatecheck.xml`.

## Parameters

*   `-Channel <String>`: (Optional) Specifies the update channel for Loxone Config. Options: `Release`, `Beta`, `Test`. Default might be `Test` or as defined in script.
*   `-DebugMode`: (Optional) Enables verbose debug logging.
*   `-EnableCRC`: (Optional) Enables CRC32 checksum verification of downloaded installers.
*   `-InstallMode <String>`: (Optional) Sets the installer mode for Loxone Config/App. Options: `silent`, `verysilent`.
*   `-CloseApplications`: (Optional) If set, forces running `LoxoneConfig.exe` instances to close before an update.
*   `-ScriptSaveFolder <String>`: (Optional) Directory to store logs, downloads, and the script itself (referenced by the scheduled task). Defaults to the script's execution directory.
*   `-MaxLogFileSizeMB <Int32>`: (Optional) Maximum size in MB for the main log file before rotation.
*   `-RegisterTask`: (Optional) If specified, the script will register/update the scheduled task and then exit.
*   `-SkipUpdateIfAnyProcessIsRunning`: (Optional) If set, the Loxone Config/App update will be skipped if `LoxoneConfig.exe` is detected running.
*   `-UpdateLoxoneApp`: (Optional) A switch to control whether the Loxone App should also be updated as part of the pipeline.
*   `-UpdateLoxoneAppChannel <String>`: (Optional) Specifies the update channel for the Loxone App if `-UpdateLoxoneApp` is used. Options: `Release`, `Beta`, `Test`.
*   `-SkipCertificateCheck`: (Optional) If set, may bypass certain certificate validation steps during download or installation (use with caution).

## Usage

1.  Ensure `UpdateLoxone.ps1` and the entire `LoxoneUtils` directory (with all its `.psm1` module files) are placed together in a stable final location (e.g., `C:\Scripts\UpdateLoxone`).
2.  (Optional) Create `UpdateLoxoneMSList.txt` in the `-ScriptSaveFolder` (defaults to script's directory) with your Miniserver details.
3.  To set up automated updates, run `UpdateLoxone.ps1` **once** interactively from its final location with the `-RegisterTask` parameter. It will request Administrator elevation if needed.
    ```powershell
    # Example: Register the task, use Release channel for Config
    .\UpdateLoxone.ps1 -RegisterTask -Channel Release
    ```
4.  This initial run (with `-RegisterTask`) creates/updates a scheduled task (typically named `LoxoneUpdateTask`) to run the script periodically as SYSTEM with highest privileges.
5.  Subsequent runs by the scheduled task will perform the update checks and installations silently based on the parameters baked into the task or defaults.

## Workflow Overview (Scheduled Task Execution)

1.  **Parameter Parsing & Context Initialization:** The script starts, parses any parameters passed by the task, and initializes its context (paths, logging, versions).
2.  **SYSTEM User Check (Initial Run Logic):** If running as SYSTEM and it's an initial invocation (not a self-relaunch), it may re-launch itself as the current interactive user to handle UI elements like `BurntToast` installations or initial prompts correctly. Subsequent operations by the task usually run fully as SYSTEM.
3.  **Import Modules:** Loads necessary functions from the `LoxoneUtils` modules.
4.  **Fetch Update Prerequisites:** Contacts `https://update.loxone.com/updatecheck.xml` to get the latest available versions for Loxone Config and App for the specified channels.
5.  **Initialize Pipeline Data:** Prepares information about update targets (Config, App, Miniservers).
6.  **Execute Update Pipeline (`LoxoneUtils.WorkflowSteps`):**
    *   **Download Loxone Config:** If an update is available.
    *   **Extract Loxone Config:** From the downloaded archive.
    *   **Install Loxone Config:** Silently.
    *   **Download Loxone App:** If an update is available and `-UpdateLoxoneApp` is enabled.
    *   **Install Loxone App:** Silently.
    *   **Check Miniserver Versions:** Compares versions on Miniservers (from `UpdateLoxoneMSList.txt`) against the just-installed Loxone Config version.
    *   **Update Miniservers:** Triggers updates on Miniservers that require it.
7.  **Error Handling & Logging:** Throughout the process, all actions, errors, and significant events are logged. `LoxoneUtils.ErrorHandling` captures detailed error information.
8.  **Toast Notifications:** `LoxoneUtils.Toast` sends notifications to the interactive user (if applicable) about the update status.
9.  **Log Rotation:** `LoxoneUtils.Logging` manages log file sizes and archives.
10. **Exit.**

## Notes

*   The script relies on specific Loxone web endpoints and behaviors which could change.
*   Check `UpdateLoxone.log` (in `-ScriptSaveFolder`) for detailed operational logs and troubleshooting.
*   Manage the scheduled task via Windows Task Scheduler (`taskschd.msc`).

## Testing

A separate script, `Run-UpdateLoxoneTests.ps1`, is provided to test the core functions within the `LoxoneUtils.psm1` module.

*   **Purpose:** Verify individual function logic in different contexts (normal, simulated task, elevated).
*   **Usage:**
    ```powershell
    # Run all tests (attempts elevation by default)
    .\Run-UpdateLoxoneTests.ps1

    # Run only tests in the 'Logging' category
    .\Run-UpdateLoxoneTests.ps1 -TestName Logging

    # Run only a specific function test
    .\Run-UpdateLoxoneTests.ps1 -TestName Get-RedactedPassword

    # Run all tests but skip the elevated run attempt
    .\Run-UpdateLoxoneTests.ps1 -SkipElevation
    ```
*   The script runs tests non-elevated first, then attempts to re-launch itself elevated (unless `-SkipElevation` is used) to run tests requiring admin rights and re-run others in an elevated context.
*   A combined summary is displayed in the initial console window after all runs complete.